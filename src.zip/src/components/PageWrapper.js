import { useContext } from "react";
import { motion } from "framer-motion";
import Link from "next/link";
import { WalletContext } from "../context/WalletContext";

const variants = {
  hidden: { opacity: 0, y: 20 },
  enter: { opacity: 1, y: 0 },
  exit: { opacity: 0, y: -20 },
};

export default function PageWrapper({ children }) {
  const { wallet, connect, disconnect } = useContext(WalletContext);

  return (
    <>
      <header style={{
        backgroundColor: "#fff",
        padding: "1rem 2rem",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
        borderBottom: "1px solid #ddd",
        position: "sticky",
        top: 0,
        zIndex: 1000
      }}>
        <Link href="/" style={{ fontWeight: "bold", fontSize: "1.2rem" }}>
          CharityChain
        </Link>

        {/* Navigation Links */}
        <nav style={{ display: "flex", gap: "1rem" }}>
          <Link href="/donor-dashboard">Donor Dashboard</Link>
          <Link href="/charity-dashboard">Charity Dashboard</Link>
          <Link href="/transparency">Transparency</Link>
        </nav>

        {/* Wallet Connect/Disconnect */}
        <div>
          {wallet ? (
            <>
              <span style={{ marginRight: "1rem" }}>
                {wallet.slice(0, 6)}...{wallet.slice(-4)}
              </span>
              <button onClick={disconnect} style={{ padding: "0.4rem 1rem" }}>
                Disconnect
              </button>
            </>
          ) : (
            <button onClick={connect} style={{ padding: "0.4rem 1rem" }}>
              Connect Wallet
            </button>
          )}
        </div>
      </header>

      <motion.div
        variants={variants}
        initial="hidden"
        animate="enter"
        exit="exit"
        transition={{ type: "easeInOut", duration: 0.4 }}
      >
        {children}
      </motion.div>
    </>
  );
}

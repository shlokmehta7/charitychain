import { useState } from "react";
import { createCampaign } from "../utils/contractFunctions";
import PageWrapper from "../components/PageWrapper";

export default function CreateCampaignPage() {
  const [description, setDescription] = useState("");
  const [goal, setGoal] = useState("");

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      await createCampaign(description, goal);
      alert("Campaign created!");
      setDescription("");
      setGoal("");
    } catch (err) {
      console.error("Error creating campaign:", err);
      alert("Failed to create campaign.");
    }
  };

  return (
    <PageWrapper>
      <div style={{ padding: "2rem", maxWidth: "600px", margin: "auto" }}>
        <h2>Create a New Campaign</h2>
        <form onSubmit={handleSubmit}>
          <div style={{ marginBottom: "1rem" }}>
            <label>Description:</label><br />
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              required
              rows={4}
              style={{ width: "100%", padding: "0.5rem" }}
            />
          </div>
          <div style={{ marginBottom: "1rem" }}>
            <label>Goal Amount (in BNB):</label><br />
            <input
              type="number"
              step="0.01"
              value={goal}
              onChange={(e) => setGoal(e.target.value)}
              required
              style={{ width: "100%", padding: "0.5rem" }}
            />
          </div>
          <button type="submit" style={{ padding: "0.7rem 1.5rem" }}>
            Create Campaign
          </button>
        </form>
      </div>
    </PageWrapper>
  );
}

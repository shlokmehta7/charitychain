import { useEffect, useState } from "react";
import styles from '../styles/Home.module.css';
import Link from 'next/link';
import Image from 'next/image';
import PageWrapper from '../components/PageWrapper';
import { getAllCampaigns } from '../utils/contractFunctions';

export default function Home() {
  const [campaigns, setCampaigns] = useState([]);

  useEffect(() => {
    async function loadCampaigns() {
      try {
        const data = await getAllCampaigns();
        setCampaigns(data);
      } catch (err) {
        console.error("Failed to load campaigns", err);
      }
    }
    loadCampaigns();
  }, []);

  return (
    <PageWrapper>
      <div className={styles.homeContainer}>
        {/* Hero Section */}
        <section className={styles.hero}>
          <h1>Transparency. Trust. Impact.</h1>
          <p>Donate with confidence. Track your impact in real-time.</p>
          <div className={styles.heroButtons}>
            <Link href="/create"><button className={styles.primary}>Create Campaign</button></Link>
            <Link href="/transparency"><button className={styles.secondary}>View Transparency</button></Link>
          </div>
        </section>

        {/* Live Campaigns */}
        <section className={styles.featured}>
          <h2>Live Campaigns</h2>
          <div className={styles.cards}>
            {campaigns.map((c) => (
              <div key={c.id} className={styles.card}>
                <Image
                  src="/images/default-campaign.jpg"
                  alt={`Campaign ${c.id}`}
                  width={400}
                  height={250}
                  className={styles.image}
                />
                <div className={styles.cardContent}>
                  <h3>Campaign #{c.id}</h3>
                  <p>{c.description}</p>
                  <p><strong>Goal:</strong> {c.goalAmount} BNB</p>
                  <p><strong>Raised:</strong> {c.totalDonated} BNB</p>
                  <Link href={`/campaign/${c.id}`}>
                    <button className={styles.viewBtn}>Donate Now</button>
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </section>
      </div>
    </PageWrapper>
  );
}

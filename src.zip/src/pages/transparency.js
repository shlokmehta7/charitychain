import { useEffect, useState } from "react";
import { getAllCampaigns } from "../utils/contractFunctions";
import styles from '../styles/Transparency.module.css';
import PageWrapper from '../components/PageWrapper';

export default function TransparencyPage() {
  const [campaigns, setCampaigns] = useState([]);

  useEffect(() => {
    async function load() {
      const all = await getAllCampaigns();
      setCampaigns(all);
    }
    load();
  }, []);

  return (
    <PageWrapper>
      <div className={styles.container}>
        <h1>Transparency Ledger</h1>
        {campaigns.map(c => (
          <div key={c.id} className={styles.card}>
            <h3>Campaign #{c.id}</h3>
            <p>{c.description}</p>
            <p><strong>Creator:</strong> {c.creator}</p>
            <p><strong>Goal:</strong> {c.goalAmount} BNB</p>
            <p><strong>Raised:</strong> {c.totalDonated} BNB</p>
            <p>Status: {c.fundsWithdrawn ? "Funds Withdrawn ✅" : "Pending 🚧"}</p>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
}

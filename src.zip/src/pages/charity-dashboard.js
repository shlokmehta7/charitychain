import { useEffect, useState } from "react";
import { getAllCampaigns } from "../utils/contractFunctions";
import { connectContract } from "../utils/connectWallet";
import styles from '../styles/CharityDashboard.module.css';
import PageWrapper from '../components/PageWrapper';

export default function CharityDashboard() {
  const [wallet, setWallet] = useState("");
  const [campaigns, setCampaigns] = useState([]);

  useEffect(() => {
    async function load() {
      const { signer } = await connectContract();
      const address = await signer.getAddress();
      setWallet(address);
      const all = await getAllCampaigns();
      const myCampaigns = all.filter(c => c.creator.toLowerCase() === address.toLowerCase());
      setCampaigns(myCampaigns);
    }
    load();
  }, []);

  return (
    <PageWrapper>
      <div className={styles.container}>
        <h1>Your Charity Campaigns</h1>
        {campaigns.map(c => (
          <div key={c.id} className={styles.card}>
            <h3>Campaign #{c.id}</h3>
            <p>{c.description}</p>
            <p><strong>Goal:</strong> {c.goalAmount} BNB</p>
            <p><strong>Raised:</strong> {c.totalDonated} BNB</p>
            <p>Status: {c.goalReached ? "Goal Reached ✅" : "In Progress ⏳"}</p>
          </div>
        ))}
      </div>
    </PageWrapper>
  );
}


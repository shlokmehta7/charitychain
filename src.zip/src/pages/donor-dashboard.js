import { useEffect, useState } from "react";
import { getUserTotalDonations } from "../utils/contractFunctions";
import { connectContract } from "../utils/connectWallet";
import styles from '../styles/DonorDashboard.module.css';
import PageWrapper from '../components/PageWrapper';

export default function DonorDashboard() {
  const [wallet, setWallet] = useState("");
  const [donated, setDonated] = useState("0");

  useEffect(() => {
    async function load() {
      const { signer } = await connectContract();
      const address = await signer.getAddress();
      setWallet(address);
      const total = await getUserTotalDonations(address);
      setDonated(total);
    }
    load();
  }, []);

  return (
    <PageWrapper>
      <div className={styles.container}>
        <h1>Your Donations</h1>
        <p>Wallet: {wallet}</p>
        <p>Total Donated: <strong>{donated} BNB</strong></p>
      </div>
    </PageWrapper>
  );
}

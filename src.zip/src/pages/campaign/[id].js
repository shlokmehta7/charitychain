import { useRouter } from 'next/router';
import { useEffect, useState, useContext } from 'react';
import PageWrapper from '../../components/PageWrapper';
import {
  getCampaignDetails,
  donateToCampaign,
  withdrawFunds
} from '../../utils/contractFunctions';
import { WalletContext } from '../../context/WalletContext';

export default function CampaignPage() {
  const router = useRouter();
  const { id } = router.query;

  const [campaign, setCampaign] = useState(null);
  const [amount, setAmount] = useState("");

  const { wallet: walletAddress } = useContext(WalletContext);

  useEffect(() => {
    if (!id) return;
    async function load() {
      const data = await getCampaignDetails(id);
      setCampaign(data);
    }
    load();
  }, [id]);

  const handleDonate = async (e) => {
    e.preventDefault();
    try {
      await donateToCampaign(id, amount);
      alert("Thank you for your donation!");
      setAmount("");
      const updated = await getCampaignDetails(id);
      setCampaign(updated);
    } catch (err) {
      console.error(err);
      alert("Donation failed.");
    }
  };

  const handleWithdraw = async () => {
    try {
      await withdrawFunds(id);
      alert("Funds withdrawn successfully!");
      const updated = await getCampaignDetails(id);
      setCampaign(updated);
    } catch (err) {
      console.error(err);
      alert("Withdrawal failed.");
    }
  };

  if (!campaign) return <PageWrapper><p>Loading campaign...</p></PageWrapper>;

  return (
    <PageWrapper>
      <div style={{ padding: '2rem', maxWidth: '700px', margin: 'auto' }}>
        <h2>Campaign #{campaign.id}</h2>
        <p><strong>Description:</strong> {campaign.description}</p>
        <p><strong>Creator:</strong> {campaign.creator}</p>
        <p><strong>Goal:</strong> {campaign.goalAmount} BNB</p>
        <p><strong>Raised:</strong> {campaign.totalDonated} BNB</p>
        <p>Status: {campaign.goalReached ? 'Goal Reached ✅' : 'Still Fundraising ⏳'}</p>

        <form onSubmit={handleDonate} style={{ marginTop: '2rem' }}>
          <label>Donate BNB:</label><br />
          <input
            type="number"
            value={amount}
            step="0.01"
            onChange={(e) => setAmount(e.target.value)}
            style={{ padding: '0.5rem', width: '200px' }}
            required
          />
          <button type="submit" style={{ marginLeft: '1rem', padding: '0.5rem 1.5rem' }}>
            Donate
          </button>
        </form>

        {/* Withdraw Button for Campaign Creator */}
        {walletAddress === campaign.creator.toLowerCase() &&
          campaign.goalReached &&
          !campaign.fundsWithdrawn && (
            <div style={{ marginTop: '2rem' }}>
              <button
                onClick={handleWithdraw}
                style={{ padding: '0.6rem 1.5rem', background: '#1d4ed8', color: 'white' }}
              >
                Withdraw Funds
              </button>
            </div>
        )}
      </div>
    </PageWrapper>
  );
}
